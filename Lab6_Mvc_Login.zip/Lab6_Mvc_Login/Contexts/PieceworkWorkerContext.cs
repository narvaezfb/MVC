﻿/*PieceworkWorkerContext.cs
 * Author: Fabian Narvaez
 * Name: Lab 6 
 * Date: 2020-11-25
 * Last Date modified: 2020-12-14
 * This model is the pieceworkWorkerCaontext file that will work along the entity framework
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Lab6_Mvc_Login.Models;

namespace Lab6_Mvc_Login.Contexts
{
    public class PieceworkWorkerContext : DbContext
    {

        public PieceworkWorkerContext(DbContextOptions<PieceworkWorkerContext> options) : base(options)
        {
        }

        public DbSet<PieceworkWorkerModel> PieceworkWorkers { get; set; }
    }
}
