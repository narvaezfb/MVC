﻿/*PieceworkWorkerModel.cs
 * Author: Fabian Narvaez
 * Name: Lab 6
 * Date: 2020-12-14
 * Last Date modified: 2020-12-14
 * This model will define the pieceworkWorker data members and attributes.
 * It also represents individual pieceworkWorker objects.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Lab6_Mvc_Login.Models
{
    public class PieceworkWorkerModel
    {
        #region constructors
        /// <summary>
        /// worker model constructor: accepts worker first name and last name, also the type of worker
        /// and number of messages sent by worker 
        /// </summary>
        /// <param name="firstNameValue"></param>
        /// <param name="lastNameValue"></param>
        /// <param name="isSeniorValue"></param>
        /// <param name="messagesValue"></param>
        public PieceworkWorkerModel(string firstNameValue, string lastNameValue, bool isSeniorValue, int messagesValue)
        {
            FirstName = firstNameValue;
            LastName = lastNameValue;
            isSeniorWorker = isSeniorValue;
            Messages = messagesValue;
        }
        /// <summary>
        /// worker model default constructor: used for inheritance
        /// </summary>
        public PieceworkWorkerModel()
        {
        }

        #endregion
        #region properties
        //Constant of the minimun and maximun possible value for number of messages
        internal const int MINIMUN_VALUE = 1;
        internal const int MAXIMUN_VALUE = 20000;
        /// <summary>
        /// Gets and sets the worker's ID, included for database purposes
        /// </summary>
        [Display(Name = "Worker ID:")]
        public int Id { get; set; }

        /// <summary>
        /// get and sets worker's first name
        /// </summary>
        [Required(AllowEmptyStrings = false, ErrorMessage = "The worker must have a first name")]
        [Display(Name = "First Name:")]
        public string FirstName { get; set; }

        /// <summary>
        /// get and sets worker's last name
        /// </summary>
        [Required(AllowEmptyStrings = false, ErrorMessage = "The worker must have a Last name")]
        [Display(Name = "Last Name:")]
        public string LastName { get; set; }

        /// <summary>
        /// worker type
        /// </summary>
        [Required]
        [Display(Name = "Senior Worker ")]
        public bool isSeniorWorker { get; set; }

        /// <summary>
        /// number of messages sent
        /// </summary>
        [Required(ErrorMessage = "You must enter the number of messages sent by worker")]
        [Range(MINIMUN_VALUE, MAXIMUN_VALUE, ErrorMessage = " The values must be between 1 and 20000")]
        [Display(Name = " Messages Sent: ")]
        public int Messages { get; set; }
        #endregion

        # region methods
        /// <summary>
        /// this method will calculate the pay of each worker depending if the worker is senior or regular worker
        /// </summary>
        /// <param name="numOfMessages"></param>
        /// <param name="isSenior"></param>
        /// <returns></returns>
        public virtual decimal FindPay(int numOfMessages, bool isSenior)
        {
            //variables
            decimal employeePay = 0M;

            //if senior is true then use a specific calculation for pay
            if (isSenior)
            {
                double[] messagesSentForSenior = new double[] { 1, 1000, 2000, 3000, 4000 };
                decimal[] pricePaidPerMessageForAllMessagesForSenior = new decimal[] { 0.010M, 0.015M, 0.020M, 0.025M, 0.030M };
                const decimal basePay = 150.00M;

                //for loop to pass the values of the arrays
                for (int index = 0; index < messagesSentForSenior.Length; index++)
                {
                    //if the number of employe message is greater than the value of the array 
                    if (numOfMessages >= messagesSentForSenior[index])
                    {
                        //set employe pay multiplicating the number of messages times the 
                        employeePay = Math.Round(((numOfMessages * pricePaidPerMessageForAllMessagesForSenior[index]) + basePay), 0);
                    }
                }
            }
            //otherwise use the normal calculation
            else
            {
                //to arrays to determinate how much the worker has to pay for every message sent
                double[] messagesSent = new double[] { 1, 1000, 2000, 3000, 4000 };
                decimal[] pricePaidPerMessageForAllMessages = new decimal[] { 0.021M, 0.028M, 0.035M, 0.040M, 0.045M };

                //for loop to pass the values of the arrays
                for (int index = 0; index < messagesSent.Length; index++)
                {
                    //if the number of employe message is greater than the value of the array 
                    if (numOfMessages >= messagesSent[index])
                    {
                        //set employe pay multiplicating the number of messages times the 
                        employeePay = Math.Round((numOfMessages * pricePaidPerMessageForAllMessages[index]), 0);
                    }
                }

            }
            //return pay
            return employeePay;
        }
        #endregion

    }
}
